#ifndef ROWER_H
#define ROWER_H

#include <string>
#include <vector>
#include <stack>
#include "kolo.h"
#include "dzwonek.h"
#include "pojazd.h"
using namespace std;

///Klasa reprezentujaca rower
class Rower : public Pojazd
{
private:
  static int licznikRowerow; ///< statyczny licznik rowerow w systemie
  int przerzutka = 5;        ///< przerzutka roweru

protected:
  vector<Kolo> kola; ///< wektor 2 kol roweru
  Dzwonek *dzwonek;  ///< wskaznik na dzwonek, ktory mozna doczepic do roweru
  /// metoda prywatna realizujaca zapis do pliku
  /**
  \param zapis strumien zapisu
  */
  void zapisz(ostream &zapis);
  /// metoda prywatna realizujaca odczyt z pliku
  /**
  \param wczyt strumien wejscia
  */
  void wczytaj(istream &wczyt);

public:
  /// Konstruktor roweru
  /**
  \param wysokosc wysokosc roweru
  \param dlugosc dlugosc roweru
  */
  Rower(float wysokosc, float dlugosc);
  /// Konstruktor kopiujacy roweru
  /**
  \param rower inny rower
  */
  Rower(const Rower &rower);
  /// Destruktor roweru
  ~Rower();
  /// Getter dla kola
  /**
  \param nr_kola wybrane kolo
  \return zwraca wybrane kolo
  */
  Kolo &getKolo(int nr_kola);
  /// Metoda pozwalajaca na doczepienie dzwonka
  /**
  \param kolor wybrany kolor dzwonka
  */
  void dodajDzwonek(string kolor);
  /// Metoda statyczna zwracajaca licznik rowerow
  /**
  \return liczba rowerow w systemie
  */
  static int getLicznikRowerow();
  /// Getter dla przerzutki
  /**
  \return zwraca aktualna przerzutke
  */
  int getPrzerzutka();
  /// Przeciazony operator przypisania dla roweru
  /**
  \param r inny rower
  \return zwraca zaktualizowany rower
  */
  Rower &operator=(const Rower &r);
  /// Przeciazony operator porownania dla roweru
  /**
  \param c inny rower
  \return zwraca true jesli rowery sa identyczne
  */
  bool operator==(const Rower &c);
  /// Przeciazony operator inkrementacji dla roweru, zwieksza przerzutke o 1
  /**
  \return zwraca ten sam rower
  */
  Rower &operator++();
  /// Przeciazony operator indeksowy dla roweru, zmienia przerzutke na dowolna inna
  /**
  \param docelowa docelowa wartosc przerzutki
  */
  void operator[](const int docelowa);
  /// Zaprzyjazniony operator strumienia wyjsciowego
  /**
  \param os strumien wyjscia
  \param rower rower wypisywany
  \return zwraca strumien
  */
  friend ostream &operator<<(ostream &os, Rower &rower);
  /// Zaprzyjazniony operator strumienia wejsciowego
  /**
  \param is strumien wejscia
  \param rower rower wypisywany
  \return zwraca strumien
  */
  friend istream &operator>>(istream &is, Rower &rower);
  /// Metoda wirtualna dla jazdy na okreslony dystans
  /**
  \param droga dystans do przebycia
  \return zwraca czas
  */
  virtual double jedz(double droga);
  /// Metoda wirtualna na wkladanie przedmiotu dla bagaznika
  /**
  \param rzecz wkladana rzecz w jednym slowie
  */
  virtual void wlozDoBagaznika(string rzecz);
};

ostream &operator<<(ostream &os, Rower &rower);
istream &operator>>(istream &is, Rower &rower);

#endif
