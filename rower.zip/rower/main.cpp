#include <iostream>
#include <fstream>
#include <vector>
#include "rower.h"
#include "motorower.h"
#include "samochod.h"
using namespace std;
/// funkcja realizujaca dodanie samochodu przez konsole
/**
 \param pojazdy wektor pojazdow
 \param typy wektor typow pojazdow
*/
void dodajSamochod(vector<Pojazd*> &pojazdy, vector<string> &typy)
{
    float wysokosc, dlugosc;
    string marka, typ_silnika;
    double moc;
    cout << "Podaj wysokosc i dlugosc samochodu" << endl;
    cin >> wysokosc >> dlugosc;
    if (!cin.good())
    {
        cout << "Nie udalo sie utworzyc samochodu" << endl
             << endl;
        return;
    }
    cout << "Podaj marke" << endl;
    cin >> marka;
    if (!cin.good())
    {
        cout << "Nie udalo sie utworzyc samochodu" << endl
             << endl;
        return;
    }
    cout << "Podaj typ i moc silnika" << endl;
    cin >> typ_silnika >> moc;
    if (!cin.good())
    {
        cout << "Nie udalo sie utworzyc samochodu" << endl
             << endl;
        return;
    }
    pojazdy.push_back(new Samochod(wysokosc, dlugosc, marka, typ_silnika, moc));
    typy.push_back("samochod");
    cout << "Samochod dodany!" << endl
         << endl;
}

/// funkcja realizujaca dodanie roweru przez konsole
/**
 \param pojazdy wektor pojazdow
 \param typy wektor typow pojazdow
*/
void dodajRower(vector<Pojazd*> &pojazdy, vector<string> &typy)
{
    float wysokosc, dlugosc;
    cout << "Podaj wysokosc i dlugosc roweru" << endl;
    cin >> wysokosc >> dlugosc;
    if (!cin.good())
    {
        cout << "Nie udalo sie utworzyc roweru" << endl
             << endl;
        return;
    }
    pojazdy.push_back(new Rower(wysokosc, dlugosc));
    typy.push_back("rower");
    cout << "Rower dodany!" << endl
         << endl;
}

/// funkcja realizujaca dodanie motoroweru przez konsole
/**
 \param pojazdy wektor pojazdow
 \param typy wektor typow pojazdow
*/
void dodajMotorower(vector<Pojazd*> &pojazdy, vector<string> &typy)
{
    float wysokosc, dlugosc;
    string typ_silnika;
    double moc;
    cout << "Podaj wysokosc i dlugosc motoroweru" << endl;
    cin >> wysokosc >> dlugosc;
    if (!cin.good())
    {
        cout << "Nie udalo sie utworzyc motoroweru" << endl
             << endl;
        return;
    }
    cout << "Podaj typ i moc silnika" << endl;
    cin >> typ_silnika >> moc;
    if (!cin.good())
    {
        cout << "Nie udalo sie utworzyc motoroweru" << endl
             << endl;
        return;
    }
    pojazdy.push_back(new Motorower(wysokosc, dlugosc, typ_silnika, moc));
    typy.push_back("motorower");
    cout << "Motorower dodany!" << endl
         << endl;
}

/// funkcja realizujaca wybranie pojazdu i przeprowadzenie z nim akcji
/**
 \param id numer pojazdu
 \param pojazdy wektor pojazdow
 \param typy wektor typow pojazdow
*/
void wybierzPojazd(int id, vector<Pojazd*> &pojazdy, vector<string> &typy)
{
    char decyzja;
    if (typy[id] == "samochod")
    {
        cout << "Co chcesz zrobic z tym samochodem?" << endl;
        cout << "1. Zapisz do pliku" << endl;
        cout << "2. Jedz!" << endl;
        cout << "3. Wloz cos do bagaznika" << endl;
        cout << "4. Wypakuj bagaznik" << endl;
    }
    if (typy[id] == "rower")
    {
        cout << "Co chcesz zrobic z tym rowerem?" << endl;
        cout << "1. Zapisz do pliku" << endl;
        cout << "2. Jedz!" << endl;
        cout << "3. Wloz cos do bagaznika" << endl;
        cout << "4. Wypakuj bagaznik" << endl;
    }
    if (typy[id] == "motorower")
    {
        cout << "Co chcesz zrobic z tym motorowerem?" << endl;
        cout << "1. Zapisz do pliku" << endl;
        cout << "2. Jedz!" << endl;
        cout << "3. Wloz cos do bagaznika" << endl;
        cout << "4. Wypakuj bagaznik" << endl;
    }
    cin >> decyzja;
    if (!cin.good())
    {
        cout << "Polecenie nierozpoznane, sprobuj ponownie" << endl
             << endl;
        return;
    }
    string rzecz, nazwa_pliku;
    double dystans;
    switch (decyzja)
    {
    case '1':
        cout << "Podaj nazwe pliku" << endl;
        cin >> nazwa_pliku;
        if (!cin.good())
        {
            cout << "Nazwa niepoprawna" << endl
                 << endl;
            return;
        }
        {
            ofstream zapis(nazwa_pliku);
            if (typy[id] == "samochod")
            {
                zapis << "samochod" << endl;
                if (Samochod *s = dynamic_cast<Samochod *>(pojazdy[id]))
                {
                    zapis << *s;
                }
            }
            if (typy[id] == "rower")
            {
                zapis << "rower" << endl;
                if (Rower *s = dynamic_cast<Rower *>(pojazdy[id]))
                {
                    zapis << *s;
                }
            }
            if (typy[id] == "motorower")
            {
                zapis << "motorower" << endl;
                if (Motorower *s = dynamic_cast<Motorower *>(pojazdy[id]))
                {
                    zapis << *s;
                }
            }
            zapis.close();
        }
        break;
    case '2':
        cout << "Podaj dystans [km]" << endl;
        cin >> dystans;
        if (!cin.good())
        {
            cout << "Dystans niepoprawny" << endl
                 << endl;
            return;
        }
        cout << "Podroz zajmie " << pojazdy[id]->jedz(dystans) << " h" << endl;
        break;
    case '3':
        cout << "Podaj rzecz (jedno slowo)" << endl;
        cin >> rzecz;
        if (!cin.good())
        {
            cout << "Rzecz niepoprawna" << endl
                 << endl;
            return;
        }
        cin.ignore();
        pojazdy[id]->wlozDoBagaznika(rzecz);
        break;
    case '4':
        cout << pojazdy[id]->wypakujBagaznik();
        break;
    default:
        cout << "Polecenie nierozpoznane, sprobuj ponownie" << endl
             << endl;
        break;
    }
}

/// funkcja glowna programu
main()
{
    vector<Pojazd*> pojazdy;
    vector<string> typy;
    while (true)
    {
        char decyzja;
        cout << endl
             << endl
             << "MENU GLOWNE" << endl;
        cout << "Wybierz opcje:" << endl;
        cout << "1. Wypisz pojazdy" << endl;
        cout << "2. Dodaj pojazd w konsoli" << endl;
        cout << "3. Wczytaj pojazd z pliku" << endl;
        cout << "4. Wybierz pojazd" << endl;
        cout << "5. Zakoncz dzialanie programu" << endl;
        cin >> decyzja;
        if (cin.good())
        {
            switch (decyzja)
            {
            case '1':
                for (int i = 0; i < pojazdy.size(); i++)
                {
                    if (typy[i] == "samochod")
                    {
                        if (Samochod *s = dynamic_cast<Samochod *>(pojazdy[i]))
                        {
                            cout << i + 1 << ". Samochod marki " << s->getMarka() << endl;
                        }
                    }
                    if (typy[i] == "rower")
                    {
                        cout << i + 1 << ". Rower" << endl;
                    }
                    if (typy[i] == "motorower")
                    {
                        cout << i + 1 << ". Motorower" << endl;
                    }
                }
                break;

            case '2':
                cout << "Wybierz typ pojazdu" << endl;
                cout << "1. Samochod" << endl;
                cout << "2. Rower" << endl;
                cout << "3. Motorower" << endl;
                cin >> decyzja;
                if (cin.good())
                {
                    switch (decyzja)
                    {
                    case '1':
                        dodajSamochod(pojazdy, typy);
                        break;
                    case '2':
                        dodajRower(pojazdy, typy);
                        break;
                    case '3':
                        dodajMotorower(pojazdy, typy);
                        break;
                    default:
                        break;
                    }
                }
                else
                {
                    cout << "Polecenie nierozpoznane, sprobuj ponownie" << endl
                         << endl;
                }
                break;

            case '3':
            {
                string nazwa_pliku, typ;
                cout << "Podaj nazwe pliku" << endl;
                cin >> nazwa_pliku;
                if (!cin.good())
                {
                    cout << "Nazwa niepoprawna" << endl
                         << endl;
                    break;
                }
                ifstream wczyt(nazwa_pliku);
                if (!wczyt.is_open())
                {
                    cout << "Nie udalo sie otworzyc pliku" << endl
                         << endl;
                    break;
                }
                wczyt >> typ;
                if (typ == "samochod")
                {
                    pojazdy.push_back(new Samochod(0, 0, "", "", 0));
                    typy.push_back("samochod");
                    if (Samochod *s = dynamic_cast<Samochod *>(pojazdy[pojazdy.size() - 1]))
                    {
                        wczyt >> *s;
                    }
                }
                else if (typ == "rower")
                {
                    pojazdy.push_back(new Rower(0, 0));
                    typy.push_back("rower");
                    if (Rower *r = dynamic_cast<Rower *>(pojazdy[pojazdy.size() - 1]))
                    {
                        wczyt >> *r;
                    }
                }
                else if (typ == "motorower")
                {
                    pojazdy.push_back(new Motorower(0, 0, "", 0));
                    typy.push_back("motorower");
                    if (Motorower *m = dynamic_cast<Motorower *>(pojazdy[pojazdy.size() - 1]))
                    {
                        wczyt >> *m;
                    }
                }
                else
                {
                    cout << "Nie rozpoznano pojazdu" << endl
                         << endl;
                }
                wczyt.close();
            }
            break;

            case '4':
                int nr;
                cout << "Podaj numer pojazdu" << endl;
                cin >> nr;
                if (!cin.good() || nr <= 0 || nr > pojazdy.size())
                {
                    cout << "Nr niepoprawny, sprobuj ponownie" << endl
                         << endl;
                    break;
                }
                wybierzPojazd(nr - 1, pojazdy, typy);
                break;

            case '5':
                exit(0);
                break;

            default:
                cout << "Polecenie nierozpoznane, sprobuj ponownie" << endl
                     << endl;
                break;
            }
        }
        else
        {
            cout << "Polecenie nierozpoznane, sprobuj ponownie" << endl
                 << endl;
        }
    }
    for(Pojazd *p : pojazdy) 
	{
    	delete p;
	}
    return 0;
}
