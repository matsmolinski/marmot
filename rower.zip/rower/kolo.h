#ifndef KOLO_H
#define KOLO_H

#include <string>
#include <iostream>
using namespace std;
/// Klasa reprezentujaca kolo
class Kolo
{
private:
  string producent_opony = "nieznany"; ///< producent opony dla danego kola

public:
  /// Konstruktor domyslny kola
  Kolo();
  /// Konstruktor kopiujacy kola
  /**
  \param kolo inne kolo
  */
  Kolo(const Kolo &kolo);
  /// Destruktor kola
  ~Kolo();
  /// Setter dla producenta opony
  /**
  \param po nowy producent opony
  */
  void setProducentOpony(string po);
  /// Przeciazony operator rzutowania, zwracajacy napis prezentujacy kolo
  operator string();
  /// Przeciazony operator przypisania dla kola
  /**
  \param k inne kolo
  \return zwraca zaktualizowane kolo
  */
  Kolo &operator=(const Kolo &k);
  /// Przeciazony operator porownania dla kola
  /**
  \param k inne kolo
  \return zwraca true jesli kola sa identyczne
  */
  bool operator==(const Kolo &k);
};

#endif