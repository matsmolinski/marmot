#include "samochod.h"
#include <iostream>
using namespace std;

Samochod::Samochod(float wysokosc, float dlugosc, string marka, string typ_silnika, double moc) {
    this->wysokosc = wysokosc;
    this->dlugosc = dlugosc;
    this->marka = marka;
    this->typ_silnika = typ_silnika;
    this->moc_silnika = moc;
    this->predkosc_max = 250;
    for (int i = 0; i < 4; i++) {
        kola.push_back(Kolo());
    }
}

Samochod::~Samochod() {}

string Samochod::getMarka(){
    return marka;
}

double Samochod::getMoc(){
    return moc_silnika;
}

string Samochod::getTypSilnika() {
    return typ_silnika;
}

Kolo &Samochod::getKolo(int nr_kola)
{
    if (nr_kola < 0 || nr_kola > 3)
    {
        return kola[0];
    }
    return kola[nr_kola];
}

double Samochod::jedz(double droga) {
    double avg_predkosc = predkosc_max - predkosc_max * (300 - moc_silnika) / 400;
    return droga / avg_predkosc;
}

void Samochod::wlozDoBagaznika(string rzecz)
{
    if (bagaznik.size() > 20)
    {
        return;
    }
    bagaznik.push(rzecz);
}

ostream &operator<<(ostream &os, Samochod &s)
{
    s.zapisz(os);
}

istream &operator>>(istream &is, Samochod &s) {
    s.wczytaj(is);
}

void Samochod::zapisz(ostream& zapis) {
    Pojazd::zapisz(zapis);
    zapis << marka << " " << typ_silnika << " " << moc_silnika << " ";
    for (Kolo k : kola) {
        zapis << (string)k << " ";
    }
    zapis << "| ";
}

void Samochod::wczytaj(istream& wczyt) {
    Pojazd::wczytaj(wczyt);
    char sign;
    wczyt >> marka >> typ_silnika >> moc_silnika;
    string op;
    for(int i = 0; i < 4; i++) {
        wczyt >> op;
        kola[i].setProducentOpony(op);
    }
    wczyt >> sign;
    if(sign != '|') {
        cout << "Ostrzezenie - dane nie sa zapisane poprawnie";
    }
}
