#ifndef SAMOCHOD_H
#define SAMOCHOD_H

#include <string>
#include <vector>
#include <stack>
#include "kolo.h"
#include "pojazd.h"

using namespace std;

/// Klasa reprezentujaca samochod
class Samochod : public Pojazd
{
private:
    string marka;       ///< marka samochodu
    string typ_silnika; ///< typ silnika danego samochodu
    double moc_silnika; ///< moc silnika samochodu
    vector<Kolo> kola;  ///< wektor 4 kol samochodu
    /// metoda prywatna realizujaca zapis do pliku
    /**
    \param zapis strumien zapisu
    */
    void zapisz(ostream &zapis);
    /// metoda prywatna realizujaca odczyt z pliku
    /**
    \param wczyt strumien wejscia
    */
    void wczytaj(istream &wczyt);

public:
    /// Konstruktor samochodu
    /**
    \param wysokosc wysokosc samochodu
    \param dlugosc dlugosc samochodu
    \param marka marka samochodu
    \param typ_silnika typ_silnika samochodu
    \param moc moc samochodu
    */
    Samochod(float wysokosc, float dlugosc, string marka, string typ_silnika, double moc);
    /// Destruktor samochodu
    ~Samochod();
    /// Getter dla marki
    /**
    \return zwraca napis z marka
    */
    string getMarka();
    /// Getter dla typu silnika
    /**
    \return zwraca typ silnika
    */
    string getTypSilnika();
    /// Getter dla mocy
    /**
    \return zwraca moc
    */
    double getMoc();
    /// Getter dla kola
    /**
    \param nr_kola wybrane kolo
    \return zwraca wybrane kolo
    */
    Kolo &getKolo(int nr_kola);
    /// Metoda wirtualna dla jazdy na okreslony dystans
    /**
    \param droga dystans do przebycia
    \return zwraca czas
    */
    virtual double jedz(double droga);
    /// Metoda wirtualna na wkladanie przedmiotu dla bagaznika
    /**
    \param rzecz wkladana rzecz w jednym slowie
    */
    virtual void wlozDoBagaznika(string rzecz);
    /// Zaprzyjazniony operator strumienia wyjsciowego
    /**
    \param os strumien wyjscia
    \param s samochod wypisywany
    \return zwraca strumien
    */
    friend ostream &operator<<(ostream &os, Samochod &s);
    /// Zaprzyjazniony operator strumienia wejsciowego
    /**
    \param is strumien wejscia
    \param s samochod wypisywany
    \return zwraca strumien
    */
    friend istream &operator>>(istream &is, Samochod &s);
};

ostream &operator<<(ostream &os, Samochod &s);
istream &operator>>(istream &is, Samochod &s);

#endif