#include "kolo.h"

Kolo::Kolo()
{
#ifdef _DEBUG
    cout << "Tworze kolo" << endl;
#endif
}

Kolo::Kolo(const Kolo &kolo)
{
    producent_opony = kolo.producent_opony;
#ifdef _DEBUG
    cout << "Tworze kolo kopiujacy" << endl;
#endif
}

Kolo &Kolo::operator=(const Kolo &k)
{
    producent_opony = k.producent_opony;
}

void Kolo::setProducentOpony(string po)
{
    producent_opony = po;
}

Kolo::operator std::string()
{
    return producent_opony;
}

Kolo::~Kolo()
{
#ifdef _DEBUG
    cout << "Usuwam kolo" << endl;
#endif
}

bool Kolo::operator==(const Kolo &k) {
    return producent_opony == k.producent_opony;
}