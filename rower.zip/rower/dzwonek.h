#ifndef DZWONEK_H
#define DZWONEK_H

#include <string>
#include <iostream>
using namespace std;

/// Klasa reprezentujaca dzwonek, opcjonalny dodatek do roweru/motoroweru
class Dzwonek
{
private:
  string kolor; ///< kolor dzwonka

public:
  /// Konstruktor dzwonka
  /**
  \param kolor kolor dzwonka 
  */
  Dzwonek(string kolor);
  /// Konstruktor kopiujacy dzwonka
  /**
  \param dzwonek inny dzwonek 
  */
  Dzwonek(const Dzwonek &dzwonek);
  /// Destruktor dzwonka
  ~Dzwonek();
  /// Getter dla koloru
  /**
  \return Zwraca kolor
  */
  string getKolor();
  /// przeciazony operator przypisania dla dzwonka
  /**
  \param d inny dzwonek 
  \return zwraca zaktualizowany dzwonek
  */
  Dzwonek &operator=(const Dzwonek &d);
};

#endif