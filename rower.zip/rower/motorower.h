#ifndef MOTOROWER_H
#define MOTOROWER_H

#include <string>
#include <vector>
#include <stack>
#include "kolo.h"
#include "pojazd.h"
#include "rower.h"

using namespace std;
/// Klasa reprezentujaca motorower
class Motorower : public Rower
{
private:
    string typ_silnika; ///< typ silnika motoroweru
    double moc_silnika; ///< moc silnika motoroweru
    /// metoda prywatna realizujaca zapis do pliku
    /**
    \param zapis strumien zapisu
    */
    void zapisz(ostream &zapis);
    /// metoda prywatna realizujaca odczyt z pliku
    /**
    \param wczyt strumien wejscia
    */
    void wczytaj(istream &wczyt);

public:
    /// Konstruktor motoroweru
    /**
    \param wysokosc wysokosc motoroweru
    \param dlugosc dlugosc motoroweru
    \param typ_silnika typ_silnika motoroweru
    \param moc moc motoroweru
    */
    Motorower(float wysokosc, float dlugosc, string typ_silnika, double moc);
    /// Destruktor motoroweru
    ~Motorower();
    /// Getter dla typu silnika
    /**
    \return zwraca typ silnika motoroweru
    */
    string getTypSilnika();
    /// Getter dla mocy silnika
    /**
    \return zwraca moc silnika
    */
    double getMoc();
    /// Getter dla kola
    /**
    \param nr_kola wybrane kolo
    \return zwraca wybrane kolo
    */
    Kolo &getKolo(int nr_kola);
    /// Metoda wirtualna dla jazdy na okreslony dystans
    /**
    \param droga dystans do przebycia
    \return zwraca czas
    */
    virtual double jedz(double droga);
    /// Metoda wirtualna na wkladanie przedmiotu dla bagaznika
    /**
    \param rzecz wkladana rzecz w jednym slowie
    */
    virtual void wlozDoBagaznika(string rzecz);
    /// Zaprzyjazniony operator strumienia wyjsciowego
    /**
    \param os strumien wyjscia
    \param mrower motorower wypisywany
    \return zwraca strumien
    */
    friend ostream &operator<<(ostream &os, Motorower &mrower);
    /// Zaprzyjazniony operator strumienia wejsciowego
    /**
    \param is strumien wejscia
    \param mrower motorower wypisywany
    \return zwraca strumien
    */
    friend istream &operator>>(istream &is, Motorower &mrower);
};

ostream &operator<<(ostream &os, Motorower &mrower);
istream &operator>>(istream &is, Motorower &mrower);

#endif
