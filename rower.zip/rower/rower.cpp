#include "rower.h"
#include <iostream>
using namespace std;

int Rower::licznikRowerow = 0;

Rower::Rower(float wysokosc, float dlugosc)
{
#ifdef _DEBUG
    cout << "Tworze rower" << endl;
#endif
    dzwonek = 0;
    licznikRowerow++;
    this->wysokosc = wysokosc;
    this->dlugosc = dlugosc;
    kola.push_back(Kolo());
    kola.push_back(Kolo());
    this->predkosc_max = 40.0;
}

Rower::Rower(const Rower &rower)
{
#ifdef _DEBUG
    cout << "Tworze rower kopiujacy" << endl;
#endif
    if (rower.dzwonek != 0)
    {
        dzwonek = new Dzwonek(*rower.dzwonek);
    }
    else
    {
        dzwonek = 0;
    }
    kola = rower.kola;
    przerzutka = rower.przerzutka;
    wysokosc = rower.wysokosc;
    dlugosc = rower.dlugosc;
    predkosc_max = rower.predkosc_max;
}

Rower::~Rower()
{
    if (dzwonek != 0)
    {
        delete dzwonek;
    }
#ifdef _DEBUG
    cout << "Usuwam rower" << endl;
#endif
}

int Rower::getLicznikRowerow()
{
    return licznikRowerow;
}

void Rower::dodajDzwonek(string kolor)
{
    if (dzwonek != 0)
    {
        delete dzwonek;
    }
    dzwonek = new Dzwonek(kolor);
}

int Rower::getPrzerzutka()
{
    return przerzutka;
}

Kolo &Rower::getKolo(int nr_kola)
{
    if (nr_kola < 0 || nr_kola > 1)
    {
        return kola[0];
    }
    return kola[nr_kola];
}

Rower &Rower::operator=(const Rower &r)
{
    kola = r.kola;
    *dzwonek = *r.dzwonek;
    przerzutka = r.przerzutka;
}

Rower &Rower::operator++()
{
    if (przerzutka < 9)
        przerzutka++;
    return *this;
}

bool Rower::operator==(const Rower &r)
{
    Rower rower(r);
    if ((kola[0] == r.kola[0] && kola[1] == r.kola[1]) == false)
    {
        return false;
    }
    return przerzutka == r.przerzutka &&
                   (r.dzwonek != 0 && dzwonek != 0)
               ? r.dzwonek->getKolor() == dzwonek->getKolor()
               : false;
}

ostream &operator<<(ostream &os, Rower &rower)
{
    rower.zapisz(os);
}

istream &operator>>(istream &is, Rower &rower) {
    rower.wczytaj(is);
}

void Rower::operator[](const int docelowa)
{
    if (docelowa > 0 && docelowa < 10)
    {
        przerzutka = docelowa;
    }
}

double Rower::jedz(double droga)
{
    double avg_predkosc = predkosc_max - predkosc_max * (9 - przerzutka) / 10;
    return droga / avg_predkosc;
}

void Rower::wlozDoBagaznika(string rzecz)
{
    if (bagaznik.size() > 3)
    {
        return;
    }
    bagaznik.push(rzecz);
}

void Rower::zapisz(ostream& zapis) {
    Pojazd::zapisz(zapis);
    zapis << przerzutka << " ";
    if (dzwonek != 0) {
        zapis << dzwonek->getKolor() << " ";
    }
    else {
        zapis << "- ";
    }
    for (Kolo k : kola) {
        zapis << (string)k << " ";
    }
    zapis << "| ";
}

void Rower::wczytaj(istream& wczyt) {
    Pojazd::wczytaj(wczyt);
    char sign;
    string dzwon;
    wczyt >> przerzutka >> dzwon;
    if(dzwon != "-") {
        this->dodajDzwonek(dzwon);
    }
    string op1, op2;
    wczyt >> op1 >> op2;
    kola[0].setProducentOpony(op1);
    kola[1].setProducentOpony(op2);
    wczyt >> sign;
    if(sign != '|') {
        cout << "Ostrzezenie - dane nie sa zapisane poprawnie";
    }
}
