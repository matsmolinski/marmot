#include "dzwonek.h"

Dzwonek::Dzwonek(string kolor)
{
    this->kolor = kolor;
#ifdef _DEBUG
    cout << "Tworze dzwonek" << endl;
#endif
}

Dzwonek::Dzwonek(const Dzwonek &dzwonek)
{
    this->kolor = dzwonek.kolor;
#ifdef _DEBUG
    cout << "Tworze dzwonek kopiujacy" << endl;
#endif
}

Dzwonek::~Dzwonek()
{
#ifdef _DEBUG
    cout << "Usuwam dzwonek" << endl;
#endif
}

string Dzwonek::getKolor()
{
    return kolor;
}

Dzwonek &Dzwonek::operator=(const Dzwonek &d)
{
    kolor = d.kolor;
}