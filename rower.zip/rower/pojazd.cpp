#include "pojazd.h"
#include <iostream>

using namespace std;

float Pojazd::getDlugosc()
{
    return dlugosc;
}

float Pojazd::getWysokosc()
{
    return wysokosc;
}

double Pojazd::getPredkoscMax()
{
    return predkosc_max;
}
Pojazd::~Pojazd() {}

string Pojazd::wypakujBagaznik()
{
    string wynik = "";
    while (!bagaznik.empty())
    {
        wynik = wynik + bagaznik.top() + "\n";
        bagaznik.pop();
    }
    return wynik;
}

void Pojazd::zapisz(ostream& zapis) {
    zapis << wysokosc << " " << dlugosc << " " << predkosc_max << " ";
    for (int i = bagaznik.size(); i--; ) {
        zapis << bagaznik.top() << " ";
        bagaznik.pop();
    }
    zapis << "| ";
}

void Pojazd::wczytaj(istream& wczyt) {
    char sign;
    wczyt >> wysokosc >> dlugosc >> predkosc_max;
    string rzecz;
    do {
        wczyt >> rzecz;
        if(rzecz != "|") {
            bagaznik.push(rzecz);
        }
    }
    while (rzecz != "|");
}