#ifndef POJAZD_H
#define POJAZD_H

#include <stack>
#include <string>
using namespace std;

/// Klasa abstrakcyjna reprezentujaca dowolny pojazd
class Pojazd
{
protected:
    float wysokosc;         ///< wysokosc pojazdu
    float dlugosc;          ///< dlugosc pojazdu
    double predkosc_max;    ///< predkosc maksymalna pojazdu
    stack<string> bagaznik; ///< stos zawierajacy bagaznik pojazdu
    /// metoda realizujaca zapis do pliku
    /**
    \param zapis strumien zapisu
    */
    void zapisz(ostream &zapis);
    /// metoda realizujaca odczyt z pliku
    /**
    \param wczyt strumien wejscia
    */
    void wczytaj(istream &wczyt);

public:
    /// Getter dla wysokosci
    /**
    \return zwraca wysokosc
    */
    float getWysokosc();
    /// Getter dla dlugosci
    /**
    \return zwraca dlugosc
    */
    float getDlugosc();
    /// Getter dla predkosci maksymalnej
    /**
    \return zwraca predkosc maksymalna
    */
    double getPredkoscMax();
    /// Metoda wirtualna dla jazdy na okreslony dystans
    /**
    \param droga dystans do przebycia
    \return zwraca czas
    */
    virtual double jedz(double droga) = 0;
    /// Metoda wirtualna na wkladanie przedmiotu dla bagaznika
    /**
    \param rzecz wkladana rzecz w jednym slowie
    */
    virtual void wlozDoBagaznika(string rzecz) = 0;
    /// Wirtualny destruktor zapobiegajacy wyciekom pamieci
    virtual ~Pojazd();
    /// Metoda wypakowujaca bagaznik
    /**
    \return zwraca napis z zawartoscia bagaznika
    */
    string wypakujBagaznik();
};

#endif