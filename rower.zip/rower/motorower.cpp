#include "motorower.h"
using namespace std;


Motorower::Motorower(float wysokosc, float dlugosc, string typ_silnika, double moc) : Rower(wysokosc, dlugosc) {
    this->typ_silnika = typ_silnika;
    this->moc_silnika = moc;
    this->predkosc_max = 45;
}

Motorower::~Motorower() {}

double Motorower::getMoc(){
    return moc_silnika;
}

string Motorower::getTypSilnika() {
    return typ_silnika;
}

Kolo &Motorower::getKolo(int nr_kola)
{
    if (nr_kola < 0 || nr_kola > 1)
    {
        return kola[0];
    }
    return kola[nr_kola];
}

double Motorower::jedz(double droga) {
    double avg_predkosc = predkosc_max - predkosc_max * (5 - moc_silnika) / 10;
    return droga / avg_predkosc;
}

void Motorower::wlozDoBagaznika(string rzecz)
{
    if (bagaznik.size() > 5)
    {
        return;
    }
    bagaznik.push(rzecz);
}

ostream &operator<<(ostream &os, Motorower &mrower)
{
    mrower.zapisz(os);
}

istream &operator>>(istream &is, Motorower &mrower) {
    mrower.wczytaj(is);
}

void Motorower::zapisz(ostream& zapis) {
    Rower::zapisz(zapis);
    zapis << typ_silnika << " " << moc_silnika << " ";
    zapis << "| ";
}

void Motorower::wczytaj(istream& wczyt) {
    Rower::wczytaj(wczyt);
    char sign;
    wczyt >> typ_silnika >> moc_silnika >> sign;
    if(sign != '|') {
        cout << "Ostrzezenie - dane nie sa zapisane poprawnie";
    }
}
